# Makes `libs` a package for imports like `libs.tools_firebase.client`
