"""Typed client for Firebase Functions tools used by agents."""

from .client import FirebaseFunctionsClient

__all__ = ["FirebaseFunctionsClient"]


