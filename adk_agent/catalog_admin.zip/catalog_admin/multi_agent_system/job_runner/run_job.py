#!/usr/bin/env python3
# Deprecated: Cloud Run job entrypoint is no longer used.
