"""
orchestrator.py - Intent Classification and Multi-Agent Routing

PURPOSE:
The orchestrator is the root agent that receives ALL user messages and routes
them to the appropriate specialist agent. It never responds directly to users.

ARCHITECTURE CONTEXT:
┌────────────────────────────────────────────────────────────────────────────┐
│                          VERTEX AI AGENT ENGINE                            │
│                                                                            │
│   ┌─────────────────────────────────────────────────────────────────────┐  │
│   │ Orchestrator (this file)                                           │  │
│   │  - Receives: (context: canvas_id=X user_id=Y corr=Z) message       │  │
│   │  - Classifies intent using rules, then LLM fallback                │  │
│   │  - Uses ADK transfer_to_agent mechanism to route                   │  │
│   │                                                                     │  │
│   │   ┌─────────────┐   ┌─────────────┐   ┌─────────────┐              │  │
│   │   │ CoachAgent  │   │ PlannerAgent│   │ CopilotAgent│              │  │
│   │   │             │   │             │   │             │              │  │
│   │   │ Education,  │   │ Create/edit │   │ Live workout│              │  │
│   │   │ analysis,   │   │ routines,   │   │ execution,  │              │  │
│   │   │ progress    │   │ workouts,   │   │ set logging,│              │  │
│   │   │ review      │   │ templates   │   │ next set    │              │  │
│   │   └─────────────┘   └─────────────┘   └─────────────┘              │  │
│   └─────────────────────────────────────────────────────────────────────┘  │
│                                                                            │
└────────────────────────────────────────────────────────────────────────────┘
           ▲                                    │
           │ SSE stream                         │ Tool calls
           │                                    ▼
┌──────────────────────┐           ┌──────────────────────────────┐
│ stream-agent-        │           │ Firebase Functions           │
│ normalized.js        │◄─────────►│ (via client.py)             │
│ (Firebase Function)  │           └──────────────────────────────┘
└──────────────────────┘

ROUTING DECISION FLOW:
1. Message arrives with context prefix
2. _auto_parse_context() extracts canvas_id, user_id, correlation_id
3. classify_intent() runs:
   a. Rule-based patterns (RULE_PATTERNS) - HIGH priority, deterministic
   b. Metric words gate (first_person + metrics) - routes to Coach
   c. Creation gate (create_verb + artifact) - routes to Planner
   d. LLM fallback (Gemini Flash) - for ambiguous messages
4. _apply_safety_reroute() checks if target has required tools
5. tool_route_to_agent() returns RoutingDecision for observability
6. ADK transfers to sub_agent (Coach, Planner, or Copilot)

INTENT TAXONOMY:
| Intent            | Target Agent | Example                           |
|-------------------|--------------|-----------------------------------|
| COACH_GENERAL     | Coach        | "What's the best rep range?"      |
| ANALYZE_PROGRESS  | Coach        | "How's my chest progress?"        |
| PLAN_WORKOUT      | Planner      | "Create a push workout"           |
| PLAN_ROUTINE      | Planner      | "Build me a PPL program"          |
| EDIT_PLAN         | Planner      | "Add more volume to that"         |
| NEXT_WORKOUT      | Copilot      | "Start my workout"                |
| EXECUTE_WORKOUT   | Copilot      | "Log that set" / "Next set"       |

DESIGN PRINCIPLES:
- Rules first, LLM fallback only when necessary
- Structured routing decisions for observability
- No artifact writes - routing only (agents handle writes)
- Safety re-route: If target agent lacks tools for request, fallback
- Conversation history tracking for context-aware LLM routing

RELATED FILES:
- coach_agent.py: Education, analysis, progress review
- planner_agent.py: Artifact creation (routines, templates, workouts)
- copilot_agent.py: Live workout execution
- shared_voice.py: Common voice/personality for all agents
- tools/coach_tools.py, planner_tools.py, copilot_tools.py: Agent tools

CALLED BY:
- Vertex AI Agent Engine via :streamQuery (from stream-agent-normalized.js)

"""

from __future__ import annotations

import logging
import os
import re
from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any, Dict, List, Optional

from google.adk import Agent
from google.adk.tools import FunctionTool

# Note: SHARED_VOICE not used for orchestrator - it needs a simple routing instruction

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


# ============================================================================
# Intent Taxonomy
# ============================================================================

class Intent(str, Enum):
    """Canonical intent labels for routing."""
    COACH_GENERAL = "COACH_GENERAL"
    ANALYZE_PROGRESS = "ANALYZE_PROGRESS"
    PLAN_WORKOUT = "PLAN_WORKOUT"
    PLAN_ROUTINE = "PLAN_ROUTINE"
    EDIT_PLAN = "EDIT_PLAN"
    EXECUTE_WORKOUT = "EXECUTE_WORKOUT"
    NEXT_WORKOUT = "NEXT_WORKOUT"


class TargetAgent(str, Enum):
    """Target agent identifiers."""
    COACH = "coach"  # Also handles analysis (data-informed coaching)
    PLANNER = "planner"
    COPILOT = "copilot"


class Confidence(str, Enum):
    """Routing confidence levels."""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


# ============================================================================
# Routing Decision
# ============================================================================

@dataclass
class RoutingDecision:
    """Structured routing decision for observability."""
    intent: str
    target_agent: str
    confidence: str
    mode_transition: Optional[str] = None
    matched_rule: Optional[str] = None
    signals: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)
    
    def to_context_string(self) -> str:
        """Format for injection into agent context."""
        parts = [
            f"intent={self.intent}",
            f"target={self.target_agent}",
            f"confidence={self.confidence}",
        ]
        if self.matched_rule:
            parts.append(f"rule={self.matched_rule}")
        if self.signals:
            parts.append(f"signals=[{','.join(self.signals)}]")
        return f"(routing: {' '.join(parts)})"


# ============================================================================
# Rule-Based Intent Classification
# ============================================================================

# Compile patterns once for performance
# DESIGN PRINCIPLE: Only include HIGH-CONFIDENCE patterns here.
# Ambiguous requests should fall through to LLM which has conversation context.
# Priority order: Copilot > Planner > Coach (data-informed) > LLM fallback
RULE_PATTERNS: List[tuple] = [
    # =========================================================================
    # COPILOT: Active workout execution (HIGHEST PRIORITY)
    # These are very specific in-workout actions that can't be confused.
    # =========================================================================
    # NOTE: Removed "start|begin|let's go" - too broad, could match "start a routine"
    (re.compile(r"\bi.?m\s+(at\s+the\s+)?gym\b|\btraining\s+now\b|\bready\s+to\s+train\b", re.I),
     Intent.EXECUTE_WORKOUT, TargetAgent.COPILOT, Confidence.HIGH, "pattern:gym_now"),
    (re.compile(r"\bnext\s+set\b|\bcurrent\s+set\b|\brest\s+timer\b|\bhow\s+much\s+rest\b", re.I),
     Intent.EXECUTE_WORKOUT, TargetAgent.COPILOT, Confidence.HIGH, "pattern:in_workout_action"),
    (re.compile(r"\b(log|record|done|finished|completed)\s+(this\s+)?(set|exercise)\b", re.I),
     Intent.EXECUTE_WORKOUT, TargetAgent.COPILOT, Confidence.HIGH, "pattern:log_set"),
    # "start my workout" / "start today's session" → Copilot
    (re.compile(r"\bstart\s+(my\s+)?(today.?s?\s+)?(workout|session|training)\b", re.I),
     Intent.NEXT_WORKOUT, TargetAgent.COPILOT, Confidence.HIGH, "pattern:start_workout"),
    (re.compile(r"\b(what.?s|show\s+me)\s+(my\s+)?(next|today.?s?)\s+(workout|session)\b", re.I),
     Intent.NEXT_WORKOUT, TargetAgent.COPILOT, Confidence.HIGH, "pattern:next_workout"),
    
    # =========================================================================
    # PLANNER: Artifact creation/edit (HIGH PRIORITY)
    # Explicit creation verbs + artifact types. Very specific.
    # =========================================================================
    # Routine/program creation (must have explicit create verb + artifact type)
    (re.compile(r"\b(create|build|make|design|set\s+up|plan\s+a|draft)\s+(a\s+)?(new\s+)?(workout\s+)?(routine|program|split|ppl|push.?pull.?legs|upper.?lower)\b", re.I),
     Intent.PLAN_ROUTINE, TargetAgent.PLANNER, Confidence.HIGH, "pattern:create_routine"),
    (re.compile(r"\b(i\s+(want|need)|give\s+me)\s+(a\s+)?(new\s+)?(workout\s+)?(routine|program|split)\b", re.I),
     Intent.PLAN_ROUTINE, TargetAgent.PLANNER, Confidence.HIGH, "pattern:want_routine"),
    # Recreate from history patterns
    (re.compile(r"\b(recreate|repeat|redo|copy)\b.*\b(last|recent|previous)\s+(workouts?|sessions?|training)\b.*\b(as\s+)?(a\s+)?(routine|program|template)?\b", re.I),
     Intent.PLAN_ROUTINE, TargetAgent.PLANNER, Confidence.HIGH, "pattern:recreate_from_history"),
    (re.compile(r"\b(last|recent|previous)\s+(workouts?|sessions?)\b.*\b(as\s+a?\s*)?(new\s+)?(routine|program|template)\b", re.I),
     Intent.PLAN_ROUTINE, TargetAgent.PLANNER, Confidence.HIGH, "pattern:history_to_routine"),
    
    # Single workout creation (explicit create verb)
    (re.compile(r"\b(create|build|make|design|plan|draft)\s+(a\s+)?(new\s+)?(single\s+)?(workout|session)\s+(for\s+)?(me|today)?\b", re.I),
     Intent.PLAN_WORKOUT, TargetAgent.PLANNER, Confidence.HIGH, "pattern:create_workout"),
    (re.compile(r"\b(i\s+(want|need)|give\s+me)\s+(a\s+)?(new\s+)?(single\s+)?(workout|session)\b", re.I),
     Intent.PLAN_WORKOUT, TargetAgent.PLANNER, Confidence.HIGH, "pattern:want_workout"),
    
    # Edit existing plan (explicit edit verb + artifact)
    (re.compile(r"\b(edit|modify|update)\s+(the\s+)?(my\s+)?(current\s+)?(workout|routine|plan|program)\b", re.I),
     Intent.EDIT_PLAN, TargetAgent.PLANNER, Confidence.HIGH, "pattern:edit_plan"),
    (re.compile(r"\b(add|remove|swap|replace)\s+(an?\s+)?(exercise|movement)\s+(in|from|to)\s+(my|the)\s+(workout|routine)\b", re.I),
     Intent.EDIT_PLAN, TargetAgent.PLANNER, Confidence.HIGH, "pattern:modify_exercise"),
    
    # =========================================================================
    # COACH (data-informed): Explicit progress/analysis requests
    # Must have clear intent to analyze personal data, not just mention "my"
    # =========================================================================
    # Explicit progress questions (very specific patterns)
    (re.compile(r"\b(am\s+i|have\s+i\s+been)\s+(progressing|improving|getting\s+stronger|doing\s+enough|growing)\b", re.I),
     Intent.ANALYZE_PROGRESS, TargetAgent.COACH, Confidence.HIGH, "pattern:am_i_progressing"),
    (re.compile(r"\bhow.?s\s+my\s+(progress|performance)\b", re.I),
     Intent.ANALYZE_PROGRESS, TargetAgent.COACH, Confidence.HIGH, "pattern:hows_my_progress"),
    
    # Explicit volume analysis questions
    (re.compile(r"\b(is\s+my|are\s+my)\s+(volume|sets|frequency)\s+(enough|sufficient|too\s+(low|high|much))\b", re.I),
     Intent.ANALYZE_PROGRESS, TargetAgent.COACH, Confidence.HIGH, "pattern:volume_adequacy"),
    (re.compile(r"\bhow\s+(much|many)\s+(volume|sets|workouts)\s+(am\s+i|have\s+i|do\s+i)\b", re.I),
     Intent.ANALYZE_PROGRESS, TargetAgent.COACH, Confidence.HIGH, "pattern:volume_count"),
    
    # Explicit muscle/exercise progress
    (re.compile(r"\bhow.?s\s+my\s+(chest|back|shoulder|leg|arm|bicep|tricep|bench|squat|deadlift)\s+(progress|doing|developing)\b", re.I),
     Intent.ANALYZE_PROGRESS, TargetAgent.COACH, Confidence.HIGH, "pattern:muscle_progress"),
    
    # Which muscles am I training
    (re.compile(r"\b(which|what)\s+(muscles?|muscle\s+groups?)\s+(am\s+i|have\s+i\s+been)\s+(training|hitting|working|developing)\s+(the\s+)?(most|least)\b", re.I),
     Intent.ANALYZE_PROGRESS, TargetAgent.COACH, Confidence.HIGH, "pattern:muscle_distribution"),
    
    # Stall/plateau detection
    (re.compile(r"\b(am\s+i|have\s+i)\s+(stall|plateau|stuck)\b", re.I),
     Intent.ANALYZE_PROGRESS, TargetAgent.COACH, Confidence.HIGH, "pattern:stall_check"),
    
    # Explicit analyze/review commands
    (re.compile(r"\b(analyze|review|assess|evaluate)\s+(my\s+)?(training|workouts?|progress|data)\b", re.I),
     Intent.ANALYZE_PROGRESS, TargetAgent.COACH, Confidence.HIGH, "pattern:analyze_data"),
    
    # NOTE: Removed broad patterns like:
    # - "my|i ... progress|trend|lately" (too loose)
    # - "my|i ... sets|volume" (could be execution context)
    # - "why/how does/what is" (catches everything)
    # - "form|technique" as single words (too broad)
    # These now fall through to LLM for context-aware classification
]

# Negative patterns to exclude (e.g., "split squat" should not trigger routine)
NEGATIVE_PATTERNS = [
    re.compile(r"\b(split\s+squat|bulgarian\s+split|split\s+stance)\b", re.I),
]


# Metric words for first-person + metrics gate (routes to Analysis)
FIRST_PERSON_WORDS = re.compile(r"\b(my|mine|i|i'm|i've|i'll|i'd)\b", re.I)
METRIC_WORDS = re.compile(r"\b(sets?|volume|frequency|sessions?|1rm|e1rm|pr|personal\s+record|over\s+time|lately|last|recent|progress|trend|stall|plateau|improving|progressing)\b", re.I)


def _extract_signals(message: str) -> List[str]:
    """Extract signal flags from message for observability."""
    signals = []
    lower = message.lower()
    
    # First-person + metrics detection (critical for routing gate)
    has_first_person = bool(FIRST_PERSON_WORDS.search(message))
    has_metric_word = bool(METRIC_WORDS.search(message))
    if has_first_person:
        signals.append("has_first_person")
    if has_metric_word:
        signals.append("has_metric_word")
    if has_first_person and has_metric_word:
        signals.append("first_person_plus_metrics")  # Strong analysis signal
    
    # Verb signals
    if re.search(r"\b(create|build|make|design|recreate|repeat|redo|copy|turn\s+into|convert)\b", lower):
        signals.append("has_create_verb")
    if re.search(r"\b(edit|modify|change|update)\b", lower):
        signals.append("has_edit_verb")
    if re.search(r"\b(analyze|review|assess)\b", lower):
        signals.append("has_analysis_verb")
    if re.search(r"\b(start|begin|go|ready)\b", lower):
        signals.append("has_action_verb")
    
    # Subject signals
    if re.search(r"\b(workout|session|training)\b", lower):
        signals.append("mentions_workout")
    if re.search(r"\b(routine|program|split|ppl)\b", lower):
        signals.append("mentions_routine")
    if re.search(r"\b(progress|history|data|performance)\b", lower):
        signals.append("mentions_data")
    if re.search(r"\b(gym|training\s+now|ready\s+to)\b", lower):
        signals.append("execution_context")
    
    # Question patterns
    if re.search(r"\b(why|how|what\s+is|explain)\b", lower):
        signals.append("is_question")
    
    # Principle/education signals (routes to Coach)
    if re.search(r"\b(best\s+practice|principles?|science|research|optimal|evidence)\b", lower):
        signals.append("has_principle_word")
    if re.search(r"\b(form|technique|cues?|feel|tempo|rom|execution)\b", lower):
        signals.append("has_technique_word")
    
    return signals


def classify_intent_rules(message: str) -> Optional[RoutingDecision]:
    """
    Classify intent using deterministic rules.
    Returns None if no rule matches (fallback to LLM needed).
    """
    # Check negative patterns first
    for neg_pattern in NEGATIVE_PATTERNS:
        if neg_pattern.search(message):
            # Don't let this influence routine detection
            pass  # For now just continue, could log
    
    signals = _extract_signals(message)
    
    # Try each pattern in priority order
    for pattern, intent, target, confidence, rule_name in RULE_PATTERNS:
        # Skip if negative pattern would give false positive
        is_negated = False
        for neg_pattern in NEGATIVE_PATTERNS:
            if neg_pattern.search(message):
                # Check if this pattern is affected
                if "routine" in rule_name or "split" in rule_name:
                    is_negated = True
                    break
        
        if is_negated:
            continue
            
        if pattern.search(message):
            return RoutingDecision(
                intent=intent.value,
                target_agent=target.value,
                confidence=confidence.value,
                matched_rule=rule_name,
                signals=signals,
            )
    
    return None


def classify_intent_llm(message: str, signals: List[str]) -> RoutingDecision:
    """
    Classify intent using LLM when rules don't match.
    Uses Gemini with conversation context for accurate classification of
    short/ambiguous messages like "okay, do it", "yes", "let's go".
    """
    logger.info("LLM fallback triggered for message: %s", message[:100])
    
    # Get conversation context for better classification
    conversation_context = get_conversation_context()
    has_context = bool(conversation_context)
    
    if has_context:
        logger.info("LLM routing with %d turns of conversation context", len(_conversation_history))
    
    try:
        import google.generativeai as genai
        
        # Use flash model for fast classification
        model = genai.GenerativeModel(os.getenv("CANVAS_ORCHESTRATOR_MODEL", "gemini-2.5-flash"))
        
        # Build prompt with conversation context if available
        if has_context:
            prompt = f"""Classify the user's latest message in this fitness app conversation.

CATEGORIES:
COACH - User wants advice, explanations, education about training principles, technique tips, progress review
PLANNER - User wants to create or modify a workout plan or routine (includes confirming a suggested plan change)
COPILOT - User is at the gym, ready to train, asking about their next set or exercise

CONVERSATION CONTEXT:
{conversation_context}

LATEST MESSAGE: "{message}"

Based on the conversation context, what is the user asking for?
- If the assistant suggested creating/modifying a routine and user confirms (e.g., "okay", "do it", "yes"), classify as PLANNER
- If the assistant was giving coaching advice and user asks a follow-up, classify as COACH
- If user is confirming starting a workout, classify as COPILOT

Respond with ONLY the category name (COACH, PLANNER, or COPILOT):"""
        else:
            # Fallback to simple classification without context
            prompt = f"""Classify this fitness app user message into ONE category:

COACH - User wants advice, explanations, education about training principles, "how do I get stronger", technique tips
PLANNER - User wants to create or modify a workout plan or routine
COPILOT - User is at the gym, ready to train, asking about their next set or exercise

Message: "{message}"

Respond with ONLY the category name (COACH, PLANNER, or COPILOT):"""

        response = model.generate_content(prompt)
        result = response.text.strip().upper()
        
        # Map to target agent (ANALYSIS routes to unified Coach)
        target_map = {
            "COACH": (Intent.COACH_GENERAL, TargetAgent.COACH),
            "ANALYSIS": (Intent.ANALYZE_PROGRESS, TargetAgent.COACH),  # Coach handles data
            "PLANNER": (Intent.PLAN_WORKOUT, TargetAgent.PLANNER),
            "COPILOT": (Intent.EXECUTE_WORKOUT, TargetAgent.COPILOT),
        }
        
        if result in target_map:
            intent, target = target_map[result]
            logger.info("LLM classified as: %s -> %s", result, target.value)
            return RoutingDecision(
                intent=intent.value,
                target_agent=target.value,
                confidence=Confidence.MEDIUM.value,
                matched_rule=f"fallback:llm_{result.lower()}",
                signals=signals,
            )
        
        # If LLM gives unexpected response, fall back to Coach
        logger.warning("LLM returned unexpected: %s, defaulting to COACH", result)
        
    except Exception as e:
        logger.error("LLM fallback failed: %s, defaulting to COACH", str(e))
    
    # Default to Coach if LLM fails or returns unexpected
    return RoutingDecision(
        intent=Intent.COACH_GENERAL.value,
        target_agent=TargetAgent.COACH.value,
        confidence=Confidence.LOW.value,
        matched_rule="fallback:llm_error",
        signals=signals,
    )


def _apply_safety_reroute(decision: RoutingDecision, signals: List[str]) -> RoutingDecision:
    """
    Safety re-route: If the target agent lacks tools for the request, fallback.
    
    Rules:
    - If user asks for artifact creation but lands on Coach: re-route to Planner
      (Coach is education-only, cannot create drafts)
    - Analysis and Copilot agents are fully functional - no reroute needed
    """
    # Check if request implies artifact creation but target is Coach
    if decision.target_agent == TargetAgent.COACH.value:
        if "has_create_verb" in signals and ("mentions_workout" in signals or "mentions_routine" in signals):
            logger.info("Safety re-route: Coach cannot create artifacts, redirecting to Planner")
            return RoutingDecision(
                intent=Intent.PLAN_WORKOUT.value,
                target_agent=TargetAgent.PLANNER.value,
                confidence=Confidence.MEDIUM.value,
                matched_rule="safety_reroute:coach_to_planner",
                signals=signals + ["safety_rerouted"],
            )
    
    # Analysis agent is fully implemented - no reroute needed
    # It fetches data and provides text responses
    
    # Copilot agent handles execution - no special reroute needed
    
    return decision


def classify_intent(message: str) -> RoutingDecision:
    """
    Main entry point for intent classification.
    Tries rules first, then metric words gate, then LLM fallback.
    """
    # Try rule-based classification first
    decision = classify_intent_rules(message)
    if decision:
        logger.info("Rule-based routing: %s -> %s (rule=%s)", 
                   decision.intent, decision.target_agent, decision.matched_rule)
        # Apply safety re-route
        decision = _apply_safety_reroute(decision, decision.signals)
        return decision
    
    # Extract signals for gate checks
    signals = _extract_signals(message)
    
    # METRIC WORDS GATE: If first-person + metrics → prefer Coach (data-informed)
    # This catches "my volume", "i've been training", "my progress lately" etc.
    if "first_person_plus_metrics" in signals:
        # Double-check: NOT asking for principles/technique (already Coach territory)
        if "has_principle_word" not in signals and "has_technique_word" not in signals:
            logger.info("Metric words gate: first_person + metrics → routing to COACH (data-informed)")
            return RoutingDecision(
                intent=Intent.ANALYZE_PROGRESS.value,
                target_agent=TargetAgent.COACH.value,
                confidence=Confidence.HIGH.value,
                matched_rule="gate:first_person_plus_metrics",
                signals=signals,
            )
    
    # CREATION GATE: If create verb + workout/routine → Planner
    if "has_create_verb" in signals and ("mentions_workout" in signals or "mentions_routine" in signals):
        logger.info("Creation gate: create_verb + workout → routing to PLANNER")
        return RoutingDecision(
            intent=Intent.PLAN_WORKOUT.value,
            target_agent=TargetAgent.PLANNER.value,
            confidence=Confidence.HIGH.value,
            matched_rule="gate:create_artifact",
            signals=signals,
        )
    
    # Fall back to LLM classification for truly ambiguous messages
    decision = classify_intent_llm(message, signals)
    logger.info("LLM-based routing: %s -> %s", decision.intent, decision.target_agent)
    # Apply safety re-route
    decision = _apply_safety_reroute(decision, decision.signals)
    return decision


# ============================================================================
# Context Management
# ============================================================================

_context: Dict[str, Any] = {
    "canvas_id": None,
    "user_id": None,
    "correlation_id": None,
    "current_mode": "coach",  # coach | analyze | plan | execute
}
_context_parsed_for_message: Optional[str] = None

# Conversation history cache for context-aware LLM routing
# Stores last N turns as (role, text) tuples
_conversation_history: List[tuple] = []
MAX_HISTORY_TURNS = 4  # Keep last 4 turns for context


def update_conversation_history(role: str, text: str) -> None:
    """
    Update the conversation history cache.
    Called by tool_route_to_agent and after agent responses.
    
    Args:
        role: 'user' or 'assistant'
        text: The message text (cleaned, without context prefix)
    """
    global _conversation_history
    
    # Skip empty messages
    if not text or not text.strip():
        return
    
    # Clean the text (remove context prefix if present)
    clean_text = _strip_context_prefix(text)
    if not clean_text:
        return
    
    # Truncate long messages for context efficiency
    max_chars = 500
    if len(clean_text) > max_chars:
        clean_text = clean_text[:max_chars] + "..."
    
    # Add to history
    _conversation_history.append((role, clean_text))
    
    # Keep only last N turns
    if len(_conversation_history) > MAX_HISTORY_TURNS:
        _conversation_history = _conversation_history[-MAX_HISTORY_TURNS:]
    
    logger.debug("Conversation history updated: %d turns", len(_conversation_history))


def get_conversation_context() -> str:
    """
    Format conversation history for LLM routing context.
    Returns empty string if no history.
    """
    if not _conversation_history:
        return ""
    
    lines = []
    for role, text in _conversation_history:
        prefix = "User" if role == "user" else "Assistant"
        lines.append(f"{prefix}: {text}")
    
    return "\n".join(lines)


def _auto_parse_context(message: str) -> None:
    """Auto-parse context from message prefix."""
    global _context_parsed_for_message
    
    if _context_parsed_for_message == message:
        return
    
    match = re.search(r'\(context:\s*canvas_id=(\S+)\s+user_id=(\S+)\s+corr=(\S+)\)', message)
    if match:
        _context["canvas_id"] = match.group(1).strip()
        _context["user_id"] = match.group(2).strip()
        corr = match.group(3).strip()
        _context["correlation_id"] = corr if corr != "none" else None
        _context_parsed_for_message = message
        logger.info("Parsed context: canvas=%s user=%s corr=%s",
                   _context.get("canvas_id"), _context.get("user_id"), _context.get("correlation_id"))


def _strip_context_prefix(message: str) -> str:
    """Remove context prefix from message for cleaner routing."""
    return re.sub(r'\(context:\s*canvas_id=\S+\s+user_id=\S+\s+corr=\S+\)\s*', '', message).strip()


# ============================================================================
# Agent Imports (lazy to avoid circular imports)
# ============================================================================

_planner_agent = None
_coach_agent = None
_analysis_agent = None
_copilot_agent = None


def _get_planner_agent():
    global _planner_agent
    if _planner_agent is None:
        from app.agents.planner_agent import PlannerAgent
        _planner_agent = PlannerAgent
    return _planner_agent


def _get_coach_agent():
    global _coach_agent
    if _coach_agent is None:
        from app.agents.coach_agent import CoachAgent
        _coach_agent = CoachAgent
    return _coach_agent


def _get_analysis_agent():
    """Analysis merged into Coach - returns CoachAgent for backwards compatibility."""
    return _get_coach_agent()


def _get_copilot_agent():
    global _copilot_agent
    if _copilot_agent is None:
        from app.agents.copilot_agent import CopilotAgent
        _copilot_agent = CopilotAgent
    return _copilot_agent


# ============================================================================
# Orchestrator Tools
# ============================================================================

def tool_route_to_agent(*, message: str) -> Dict[str, Any]:
    """
    Classify intent and route to appropriate agent.
    Returns the routing decision for observability.
    """
    # Parse context if present
    _auto_parse_context(message)
    
    # Strip context for cleaner classification
    clean_message = _strip_context_prefix(message)
    
    # Track user message in conversation history for context-aware LLM routing
    # This enables "okay, do it" to route correctly based on previous turns
    update_conversation_history("user", clean_message)
    
    # Classify intent
    decision = classify_intent(clean_message)
    
    # Update session mode based on routing
    mode_map = {
        TargetAgent.COACH.value: "coach",
        TargetAgent.PLANNER.value: "plan",
        TargetAgent.COPILOT.value: "execute",
    }
    old_mode = _context.get("current_mode", "coach")
    new_mode = mode_map.get(decision.target_agent, "coach")
    
    if old_mode != new_mode:
        decision.mode_transition = f"{old_mode}→{new_mode}"
        _context["current_mode"] = new_mode
    
    logger.info("Routing decision: %s", decision.to_dict())
    
    return {
        "routing_decision": decision.to_dict(),
        "context": {
            "canvas_id": _context.get("canvas_id"),
            "user_id": _context.get("user_id"),
            "correlation_id": _context.get("correlation_id"),
            "current_mode": _context.get("current_mode"),
        }
    }


# ============================================================================
# Orchestrator Agent Definition
# ============================================================================

# ORCHESTRATOR INSTRUCTION - Simple, proven instruction from beed800
# Key: Says "Transfer to" which ADK recognizes for sub_agent routing
# NO generate_content_config - let the model use default token limits
ORCHESTRATOR_INSTRUCTION = """
You are the Orchestrator Agent. Your sole job is to classify user intent and route to the correct specialist agent.

PROCESS:
1. For every message, parse the context prefix (canvas_id, user_id, correlation_id)
2. Classify the user's intent using the routing rules
3. Transfer to the appropriate specialist agent with the routing context

ROUTING:
- Coach: Education, explanations, training principles, progress review, data analysis (handles both coaching AND analysis)
- Planner: Create/edit workouts and routines (draft artifacts)
- Copilot: Live workout execution, in-session adjustments (active workout writes)

You must ALWAYS route to one of the three specialist agents. Never respond directly.
Include the routing decision in your transfer for observability.
"""

# Orchestrator uses sub_agents for ADK transfer mechanism
# NO generate_content_config - this was causing truncation issues
OrchestratorAgent = Agent(
    name="Orchestrator",
    model=os.getenv("CANVAS_ORCHESTRATOR_MODEL", "gemini-2.5-flash"),
    instruction=ORCHESTRATOR_INSTRUCTION,
    tools=[FunctionTool(func=tool_route_to_agent)],
    sub_agents=[],  # Will be populated after agent definitions
)


def _build_orchestrator_with_agents() -> Agent:
    """Build orchestrator with all sub-agents attached."""
    return Agent(
        name="Orchestrator",
        model=os.getenv("CANVAS_ORCHESTRATOR_MODEL", "gemini-2.5-flash"),
        instruction=ORCHESTRATOR_INSTRUCTION,
        tools=[FunctionTool(func=tool_route_to_agent)],
        sub_agents=[
            _get_coach_agent(),    # Coach (handles both coaching + analysis)
            _get_planner_agent(),  # Planner (artifact creation/editing)
            _get_copilot_agent(),  # Copilot (in-workout execution)
        ],
        # NO generate_content_config - let model use defaults
    )


# Lazy initialization for root_agent
_root_agent = None


def get_root_agent() -> Agent:
    """Get the fully initialized orchestrator agent."""
    global _root_agent
    if _root_agent is None:
        _root_agent = _build_orchestrator_with_agents()
    return _root_agent


# For module-level export compatibility
root_agent = property(lambda self: get_root_agent())


class _RootAgentProxy:
    """Proxy class to lazily initialize root_agent on first access."""
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = get_root_agent()
        return cls._instance


# This will be the exported root_agent
root_agent = None  # Placeholder, actual initialization in __init__.py or agent.py


def initialize_root_agent() -> Agent:
    """Initialize and return the root orchestrator agent."""
    global root_agent
    root_agent = _build_orchestrator_with_agents()
    return root_agent


__all__ = [
    "OrchestratorAgent",
    "RoutingDecision",
    "Intent",
    "TargetAgent",
    "Confidence",
    "classify_intent",
    "initialize_root_agent",
    "root_agent",
    "update_conversation_history",  # For tracking assistant responses
]
